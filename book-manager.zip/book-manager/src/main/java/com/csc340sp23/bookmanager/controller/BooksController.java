
package com.csc340sp23.bookmanager.controller;

import com.csc340sp23.bookmanager.books.Books;
import com.csc340sp23.bookmanager.service.BooksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author Hilda Ramirez
 */
@Controller
@RequestMapping("/book")
public class BooksController {

    @Autowired
    private BooksService booksService;
  
    


   // html list-products
    @GetMapping("/all")
     public String getBooks(Model model) {
        model.addAttribute("bookList", booksService.getAllBooks());
        return "book/list-books";
    }
     // was product-detail now book detail html file
      @GetMapping("/id={bookId}")
    public String getBook(@PathVariable long bookId, Model model) {
        model.addAttribute("book", booksService.getBook(bookId));
        return "book/book-detail";
    }
     @GetMapping("/delete/id={bookId}")
    public String deleteBook(@PathVariable long bookId, Model model) {
        booksService.deleteBook(bookId);
        return "redirect:/book/all";
    }
    @PostMapping("/create")
    public String createBook(Books book) {

        booksService.saveBook(book);
        return "redirect:/book/all";
    }
    @PostMapping("/update")
    public String updateBooks(Books book) {
        booksService.saveBook(book);
        return "redirect:/book/all";
    }
    
    // was newbook an html file
     @GetMapping("/new-book")
    public String newbookForm(Model model) {
        return "book/new-book";
    }
     @GetMapping("/update/id={bookId}")
    public String updateProductForm(@PathVariable long bookId, Model model) {
        model.addAttribute("book", booksService.getBook(bookId));
        return "book/update-book";
    }
}
