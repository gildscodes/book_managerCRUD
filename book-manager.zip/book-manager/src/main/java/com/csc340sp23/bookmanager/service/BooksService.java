
package com.csc340sp23.bookmanager.service;

import com.csc340sp23.bookmanager.books.Books;
import com.csc340sp23.bookmanager.repository.BookRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Hilda
 */
@Service
public class BooksService{

    @Autowired
    private BookRepository bookRepository;

    // getting all of the book records using findAll method of crudRepo
   public List<Books> getAllBooks() {
        return bookRepository.findAll();
    }
    public Books getBook(long bookId) {
        return bookRepository.getReferenceById(bookId);
    }
    
     public void deleteBook(long bookId) {
        bookRepository.deleteById(bookId);
    }
   
      public void saveBook(Books book) {

        bookRepository.save(book);
    }

  

}
