
package com.csc340sp23.bookmanager.repository;

import com.csc340sp23.bookmanager.books.Books;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Hilda
 */
public interface BookRepository extends JpaRepository<Books, Long>{
    
}
